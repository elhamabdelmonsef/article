﻿=== Firebase Push Notification ===
Contributors:sony7596, miraclewebssoft, reachbaljit
Tags: Firebase cloud messsaging, FCM, Firebase cloud messsaging for Adroid, Firebase cloud messsaging for IOS, Firebase cloud messsaging on Post save,Firebase cloud messsaging on page save, FCM push Notification 
Donate link: https://www.paypal.me/KaramSingh
Requires at least:3.6
Tested up to:4.9
Stable tag:3.2
License:GPL2
License URI:https://www.gnu.org/licenses/gpl-2.0.html

Firebase cloud messsaging(FCM) for Android and IOS on post save, post update, page save and page update with Device Topic.
 
== Description ==
Firebase cloud messsaging(FCM) for Android and IOS on post save, post update, page save and page update. You google FCM API key and Device Topic. 
 
 
**Plugin features:-** 

* Firebase cloud messsaging(FCM) for Android and IOS
* Firebase cloud messsaging(FCM) on post save
* Firebase cloud messsaging(FCM) on post update
* Firebase cloud messsaging(FCM) on page save
* Firebase cloud messsaging(FCM) on page update


**How to use Plugin:-**

* After install goto Firebase Push Notification under Settings in wordpress admin menu
* Enter Google firebase api key to field given.
* Setup any topic in mobile application and same token put in option given.
* Disable notification for post or page if needed.

**Need More features contact us:-**

* <a href="https://www.miraclewebsoft.com/contact/" target="_blank">Contact us</a>


== Installation ==
Download the plugin .zip file

Login in to admin Click Plugins -> Add New -> Upload

Find wp-firebase-push-notification Wordpress Plugin in plugin list and activate it.

Now goto Firebase Push Notification under Settings in admin menu

== Screenshots ==

== Changelog ==
= 3.1 |19/05/2018 =

* Fix the notification for new post and update post

= 1 =

* Initial Release 1.0