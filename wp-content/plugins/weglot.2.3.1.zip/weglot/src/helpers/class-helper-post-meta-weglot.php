<?php

namespace WeglotWP\Helpers;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @since 2.1.0
 */
class Helper_Post_Meta_Weglot {

	/**
	 * @var string
	 */
	const POST_NAME_WEGLOT = 'post_name_weglot';
}
